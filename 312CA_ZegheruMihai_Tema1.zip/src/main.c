/**
 *	Copyright (c) 2023-2024 | Mihai Zegheru | 312CAb
*/

#include <app_manager.h>

int main(void)
{
	app_main_loop();

	return 0;
}
